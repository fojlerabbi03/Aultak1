'use client';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2 } from 'lucide-react';

const methods = [
  { id: 'bkash', label: 'bKash', color: 'bg-pink-600' },
  { id: 'nagad', label: 'Nagad', color: 'bg-orange-500' },
  { id: 'rocket', label: 'Rocket', color: 'bg-purple-600' },
  { id: 'cod', label: 'Cash on Delivery', color: 'bg-gray-700 border border-gray-500' },
];

export default function Checkout() {
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);

  const handlePlaceOrder = async () => {
    if (!selected) return;
    setLoading(true);

    // Call Backend
    const res = await fetch('http://localhost:3001/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: 'customer@example.com', // In real app, get from user session
        items: [{ name: 'Premium Cotton Shirt', price: 120 }],
        total: 120,
        payment_method: selected
      })
    });

    setLoading(false);
    setOrderPlaced(true);
  };

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-aultak-black flex items-center justify-center text-white">
        <div className="text-center">
          <h2 className="text-4xl font-serif mb-4 text-aultak-gold">Order Confirmed</h2>
          <p>Check your email for the invoice.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-aultak-black text-white flex flex-col items-center justify-center p-10">
      <h1 className="text-3xl font-serif mb-10">Secure Checkout</h1>
      
      <div className="grid grid-cols-2 gap-4 w-full max-w-md">
        {methods.map((method) => (
          <motion.div
            key={method.id}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setSelected(method.id)}
            className={`
              p-6 rounded-xl cursor-pointer flex items-center justify-center font-bold text-lg
              transition-all duration-300
              ${selected === method.id ? `${method.color} ring-4 ring-white` : 'bg-aultak-gray text-gray-400'}
            `}
          >
            {method.label}
          </motion.div>
        ))}
      </div>

      <motion.button
        onClick={handlePlaceOrder}
        disabled={!selected || loading}
        className="mt-10 px-10 py-4 bg-white text-black font-bold text-xl rounded-full disabled:opacity-50"
        whileTap={{ scale: 0.9 }}
      >
        {loading ? <Loader2 className="animate-spin" /> : 'Place Order'}
      </motion.button>